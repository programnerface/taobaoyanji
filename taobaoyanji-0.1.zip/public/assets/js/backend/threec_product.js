define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'threec_product/index' + location.search,
                    add_url: 'threec_product/add',
                    edit_url: 'threec_product/edit',
                    // del_url: 'threec_product/del',
                    multi_url: 'threec_product/multi',
                    import_url: 'threec_product/import',
                    table: 'treecproduct',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'store_name', title: __('Store_name'), operate: 'LIKE'},
                        {field: 'platform_order_id', title: __('Platform_order_id'), operate: 'LIKE'},
                        {field: 'merchant_order_id', title: __('Merchant_order_id'), operate: 'LIKE'},
                        {field: 'category', title: __('Category'), operate: 'LIKE'},
                        {field: 'energy_efficiency_level', title: __('Energy_efficiency_level'), operate: 'LIKE'},
                        {field: 'brand', title: __('Brand'), operate: 'LIKE'},
                        {field: 'product_model', title: __('Product_model'), operate: 'LIKE'},
                        {field: 'order_amount', title: __('Order_amount'), operate:'BETWEEN'},
                        {field: 'actual_paid_amount', title: __('Actual_paid_amount'), operate:'BETWEEN'},
                        {field: 'transaction_time', title: __('Transaction_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'gov_subsidy_amount', title: __('Gov_subsidy_amount'), operate:'BETWEEN'},
                        {field: 'sn_image_url', title: __('Sn_image_url'), operate: 'LIKE',
                            buttons:[
                                {
                                    name: 'detail',
                                    title: __('SN图片OCR识别'),
                                    classname: 'btn btn-xs btn-primary btn-dialog',
                                    icon: 'fa fa-list',
                                    url: 'threec_product/sn_ocr',
                                    success: function (layero, index) {
                                        alert("诊断第1步：success 回调函数被触发了！");
                                        console.log("诊断第1步：success 回调函数被触发了！", layero);

                                        try {
                                            // layero 是弹窗的jQuery对象，我们尝试在里面寻找图片
                                            var imageElement = layero.find("img.dialog-image-final"); // 假设html里的图片class是这个

                                            if (imageElement.length > 0) {
                                                alert("诊断第2步：成功在弹窗中找到了图片元素！");
                                                console.log("诊断第2步：成功在弹窗中找到了图片元素！", imageElement);

                                                // 我们不调用复杂的插件，只做一个最简单的操作：把图片边框变红
                                                imageElement.css('border', '5px solid red');
                                                alert("诊断第3步：已尝试将图片边框变为红色。请检查弹窗中的图片。");
                                                console.log("诊断第3步：已尝试将图片边框变为红色。");

                                            } else {
                                                alert("诊断失败：success回调已触发，但在弹窗中找不到 'img.dialog-image-final'。");
                                                console.error("诊断失败：success回调已触发，但在弹窗中找不到 'img.dialog-image-final'。");
                                            }
                                        } catch (e) {
                                            alert("诊断异常：在success回调函数内部发生错误: " + e.message);
                                            console.error("诊断异常：在success回调函数内部发生错误:", e);
                                        }
                                    },
                                    callback: function (data) {
                                        Layer.alert("接收到回传数据：" + JSON.stringify(data), {title: "回传数据"});
                                    }
                                },
                            ],
                            table: table, formatter: Table.api.formatter.operate
                           },
                        {field: 'inspection_image_url', title: __('Inspection_image_url'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.images},
                        {field: 'screen_on_image_url', title: __('Screen_on_image_url'), operate: 'LIKE', formatter: Table.api.formatter.url},
                        {field: 'ean_code', title: __('Ean_code'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'serial_number', title: __('Serial_number'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'imei1', title: __('Imei1'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'imei2', title: __('Imei2'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'invoice_number', title: __('Invoice_number'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'invoice_date', title: __('Invoice_date'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'invoice_url', title: __('Invoice_url'), operate: 'LIKE', formatter: Table.api.formatter.url},
                        {field: 'invoice_header', title: __('Invoice_header'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'invoice_amount', title: __('Invoice_amount'), operate:'BETWEEN'},
                        {field: 'seller_tax_id', title: __('Seller_tax_id'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'tracking_number', title: __('Tracking_number'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'tracking_map_url', title: __('Tracking_map_url'), operate: 'LIKE', formatter: Table.api.formatter.url},
                        {field: 'shipping_company', title: __('Shipping_company'), operate: 'LIKE'},
                        {field: 'recipient_province', title: __('Recipient_province'), operate: 'LIKE'},
                        {field: 'recipient_city', title: __('Recipient_city'), operate: 'LIKE'},
                        {field: 'recipient_district', title: __('Recipient_district'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'recipient_address', title: __('Recipient_address'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'delivery_time', title: __('Delivery_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'verification_status', title: __('Verification_status'), searchList: {"Success":__('Success'),"Failure":__('Failure')}, formatter: Table.api.formatter.status},
                        // {field: 'operate', title: __('Operate'), table: table,events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
