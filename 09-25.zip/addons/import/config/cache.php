<?php 
 return array (
  'table_name' => 'fa_import_log',
  'self_path' => '',
  'update_data' => '',
);