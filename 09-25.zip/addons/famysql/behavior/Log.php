<?php

namespace addons\famysql\behavior;

class Log
{
    public function run(&$params)
    {
        //只记录POST请求的日志
        if (request()->isPost() && get_addon_config('famysql')['is_check']) {
            $table_name = $params['name'];
            $sql = $params['sql'];

            $prefix = \think\Config::get('database.prefix');

            $name = ltrim($table_name, $prefix);

            $tmp = explode('_', $name);

            if ($tmp && get_addon_info($tmp[0])) {
                \addons\famysql\library\Log::record($tmp[0], $sql);
            }
        }
    }
}
