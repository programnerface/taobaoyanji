<?php

namespace addons\famysql\library;

class Log
{
    public static function record($name, $sql)
    {
        $addon_info = get_addon_info($name);
        $version = $addon_info['version'];
        $file = ADDON_PATH . $name . DS . 'install.sql';
        $content = file_get_contents($file);

        if (version_compare($version, '1.0.0', '<=')) {
            return;
        }

        $version_str = '-- ' . $version . ' --';

        if (strpos($content, $version_str) !== false) {
        } else {
            $content .= PHP_EOL;
            $content .= PHP_EOL;
            $content .= $version_str . PHP_EOL;
        }

        if (is_array($sql)) {
            $sql = implode(PHP_EOL . PHP_EOL, $sql);
            $content .= $sql . PHP_EOL;
        } else {
            $content .= $sql . PHP_EOL;
        }

        $prefix = \think\Config::get('database.prefix');

        if ($prefix !== '') {
            $content = str_replace("`" . $prefix, '`__PREFIX__', $content);
        }

        file_put_contents($file, $content);
    }
}
