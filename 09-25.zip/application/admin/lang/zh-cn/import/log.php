<?php

return [
    'Table'         => '目标表',
    'NewTable'         => '新建表',
    'Attachment_id' => '附件ID',
    'Path'          => '文件路径',
    'Admin_id'      => '操作员',
    'Createtime'    => '添加时间',
    'Updatetime'    => '更新时间',
    'Imported'      => '是否已导入',
    'Row'           => '从第几行导入',
    'Head_type'     => '匹配方式',
    'Comment'       => '注释',
    'Name'          => '字段名',
    'Status'        => '状态',
    'Normal'        => '已导入',
    'Hidden'        => '未导入',
];
