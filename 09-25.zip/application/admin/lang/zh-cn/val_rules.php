<?php

return [
    'Id'                    => '主键自增ID',
    'Rule_id'               => '规则唯一标识符',
    'Rule_name'             => '规则名称',
    'Rule_type'             => '规则类型',
    'Source_table'          => '数据源表名',
    'Source_field'          => '数据源字段名',
    'Target_table'          => '目标表名',
    'Target_field'          => '目标字段名',
    'Validation_expression' => '校验表达式',
    'Expected_value'        => '期望值',
    'Error_message'         => '错误信息',
    'Priority'              => '优先级',
    'Is_active'             => '是否启用',
    'Created_time'          => '创建时间',
    'Updated_time'          => '更新时间'
];
