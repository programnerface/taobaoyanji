<?php

return [
    'Name'                  => '索引名',
    'Column_name'           => '列名',
    'Non_unique'            => '索引类型',
    'Table Operate'         => '表操作',
];                