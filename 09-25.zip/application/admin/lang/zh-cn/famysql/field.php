<?php

return [
    'Name'                        => '字段名称',
    'Suffix'                      => '字段后缀',
    'Type'                        => '字段类型',
    'Length'                      => '字段长度',
    'Set vlaue'                   => '枚举/设置值',
    'Default'                     => '默认值',
    'Is_null'                     => '非空?',
    'Unsigned'                    => 'unsigned',
    'Zerofill'                    => 'zerofill?',
    'Comment'                     => '注释',
    'Remark'                      => '备注',
    'Comment placeholder'         => '注释',
    'Remark placeholder'          => '备注',
    'Default placeholder'         => '字段默认值，错误的默认值会保存失败',
    'Length placeholder'          => '字段长度，浮点类型可用“10,2”方式表示',
    'Name placeholder'            => '字段名称，不可重复',
    'Batch generate'              => '批量生成',
    'Table Operate'               => '表操作',
];                