<?php

return [
    'Id'                                 => 'ID',
    'Pid'                                => '父ID',
    'Type'                               => '类型',
    'All'                                => '全部',
    'Image'                              => '图片',
    'Keywords'                           => '关键字',
    'Description'                        => '描述',
    'Diyname'                            => '自定义名称',
    'Createtime'                         => '创建时间',
    'Updatetime'                         => '更新时间',
    'Weigh'                              => '权重',
    'Category warmtips'                  => '温馨提示：栏目类型请前往<b>常规管理</b>-><b>系统配置</b>-><b>字典配置</b>中进行管理',
    'Can not change the parent to child or itself' => '父组别不能是它的子组别或它自己',
    'Status'                             => '状态'
];
